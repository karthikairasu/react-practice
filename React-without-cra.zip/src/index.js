// import React from 'react';
// import ReactDOM from 'react-dom';
// import App from './components/App.js';

// ReactDOM.render(<App/>, document.getElementById('root'));

import React from 'react';
import ReactDOM from 'react-dom/client';  // Import from 'react-dom/client' for React 18+
import App from './components/App.js';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
