## React without Create-react-app   

    1.npm init -y  =>               
                        Initialization to the package file
    2.npm install react => 
                        install to the react packages
    3.npm install react-dom =>
                        install to allows React to interact with the browser DOM
    4.npm install webpack --save-dev =>
                        Webpack is a build tool, So it's only needed during development or build time, not in production.
    5.npm install webpack-cli --save-dev =>
                        webpack-cli: Provides the necessary CLI commands to interact with Webpack via terminal or npm scripts.
    6.npm install webpack-dev-server --save-dev =>
                        installs the Webpack Dev Server, a development-only tool that provides a local server with live reloading for faster development.
    7.npm install @babel/core --save-dev =>
                        @babel/core is the heart of the Babel toolchain — it provides the APIs needed to transpile JavaScript code. Transform JSX (used in React) into plain JavaScript. You only need Babel to transform your code during development or build time, not in production.
    8.npm install babel-loader --save-dev => 
                        installs babel-loader, which is the bridge between Babel and Webpack. babel-loader lets Webpack use Babel to transpile your JavaScript files as part of your build process.Without it, Webpack can't understand Babel's transformations (like converting JSX or ES6+ syntax to ES5). babel-loader tells Webpack: 
                            - "Hey, before bundling this file, pass it through Babel."
    9.npm install @babel/preset-react --save-dev => 
                        installs the Babel preset that allows Babel to understand and transform JSX and other React-specific syntax into plain JavaScript.
                        It tells Babel how to handle:
                            - JSX: e.g. <div>Hello</div> → React.createElement('div', null, 'Hello')
                            - React-specific features like the new JSX transform (optional)
                        Without this preset, Babel will throw syntax errors when it encounters JSX in your React components.
                            - Transpiles modern JavaScript (@babel/preset-env)
                            - Transpiles React/JSX (@babel/preset-react)
    10.npm install @babel/preset-env --save-dev  =>
                        installs the Babel preset that enables Babel to transpile modern JavaScript (ES6/ES7/ESNext) into code that works in older browsers. Makes your code backward-compatible with older environments.
    11.npm install html-webpack-plugin --save-dev => 
                        installs the html-webpack-plugin, which is a very commonly used Webpack plugin for handling HTML files in your project during development and build.
                            - Automatically generates an index.html (or uses a template you provide).
                            - Injects your bundled JavaScript files into the HTML (via <script> tags).
                            - Can also include your CSS or other assets, depending on your setup.
                            - Helps avoid the need to manually manage <script> tags or update filenames after builds (like bundle.[hash].js).

 ### WebPack Config:

                Step1. webpack.config.js file create, and exports module `entry : './src/index.js'`

                Step2. create src folder, and inside `index.js` file create

                        `import React from 'react';
                        import ReactDOM from 'react-dom';
                        import App from './app.js';

                        ReactDOM.render(<App/>, document.getElementById('root'));`

                Step3. App.js file create

                        `import React from 'react';

                            const App = () =>{
                                return(
                                    <>
                                    <h2>Hello World</h2>
                                    </>
                                )
                            }

                            export default App;`
                        
                Step4. webpack.config.js modified

                        `const path = require('path');
                        const HTMLWebpackPlugin = require('html-webpack-plugin');

                        module.exports = {
                            entry : './src/index.js',

                            output : {
                                path: path.join(__dirname, '/dist'),
                                filename: 'bundle.js'
                            },

                            plugin: [
                                new HTMLWebpackPlugin({
                                    template: './src/index.html'
                                })
                            ],

                            module:{
                                rules:[
                                    {
                                        test: /.js$/,
                                        exclude: /node_modules/,
                                        use:{
                                            loader: 'babel-loader',
                                            options:{
                                                presets: ['@babel/preset-env', '@babel/preset-react']
                                            }
                                        }
                                    }
                                ]
                            }


                        }`

                Step5. create `index.html` file

                        `<!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Document</title>
                        </head>
                        <body>
                            
                            <div id="root"></div>

                        </body>
                        </html>`

                Step6. Update `package.json` file

                        `"scripts": {
                            "start": "webpack-dev-server --mode development --open --hot",
                            "build": "webpack --mode production"
                        },`

## Reference 
### Create a React App WITHOUT Create React App - https://www.youtube.com/watch?v=h3LpsM42s5o